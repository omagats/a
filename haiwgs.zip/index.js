process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"
import { fileURLToPath } from 'url'
import { join, dirname } from 'path'
import { spawn } from 'child_process'

const __dirname = dirname(fileURLToPath(import.meta.url))
function start() {
	const args = [join(__dirname, 'main.js'), ...process.argv.slice(2)]
	const terminal = spawn(process.argv[0], args, {
		stdio: [
		  'inherit',
		  'inherit',
		  'inherit',
		  'ipc'
		]
	})	
	terminal.on('exit', code => {
		console.log('Exited with code :', code)
		if (code == '.' || code == 1 || code == 0 || code == null) start()
	})
}
start()