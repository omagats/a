export default {
	bot: {
		pairingBotNumber: '62831484716370',
		sessionsName: 'pokes'
	},
	
	owner: {
		number: '62831484716370',
		additionalOwner: ['6281333298637', '6283897735196', '6287875825417', '6283181513823', '6283128559007']
	},
	
	autoKickFromAllGroup: false,
	sendViewOnce: true,
	
	textCheckpoint: /http|https|whatsapp.com|wa.me|bayar|tarif|syarat|order|test|ready|readi|saldo|bonus|open|dana|ovo|gopay|qris|basi|list|oven|bit|biz|com|my.id|0k|1k|2k|3k|4k|5k|6k|7k|8k|9k/i,
	cmdPrefix: /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
}
